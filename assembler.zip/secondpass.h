/*
 * secondpass.h
 *
 *  Created on: Mar 14, 2020
 *      Author: user
 */

#ifndef SECONDPASS_H_
#define SECONDPASS_H_

int secondPass(struct assemblerContext* context);

#endif /* SECONDPASS_H_ */
