/*
 * firstpass.h
 *
 *  Created on: Mar 10, 2020
 *      Author: user
 */

#ifndef FIRSTPASS_H_
#define FIRSTPASS_H_

#include "assembler.h"


int firstPass(struct assemblerContext* context);


#endif /* FIRSTPASS_H_ */
